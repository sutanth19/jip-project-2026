import Navbar from "../components/layout/Navbar";

export default function LandingPage() {
  return (
    <>
      <Navbar />

      <main className="min-h-screen">
        <section className="flex h-[80vh] items-center justify-center">
          <h1 className="text-5xl font-bold">
            Welcome to Digital MoLIB
          </h1>
        </section>
      </main>
    </>
  );
}