import { APP_NAME, APP_TAGLINE } from "@/config/constants";

type LogoProps = {
  showText?: boolean;
  size?: "sm" | "md" | "lg";
};

export default function Logo({
  showText = true,
  size = "md",
}: LogoProps) {
  const sizes = {
    sm: {
      box: "h-8 w-8",
      title: "text-base",
      subtitle: "text-[10px]",
    },
    md: {
      box: "h-10 w-10",
      title: "text-lg",
      subtitle: "text-xs",
    },
    lg: {
      box: "h-12 w-12",
      title: "text-xl",
      subtitle: "text-sm",
    },
  };

  const current = sizes[size];

  return (
    <div className="flex items-center gap-3">
      <div
        className={`${current.box} flex items-center justify-center rounded-xl bg-[var(--primary)] font-bold text-white shadow-md`}
      >
        M
      </div>

      {showText && (
        <div className="leading-tight">
          <h1 className={`${current.title} font-bold text-[var(--text)]`}>
            {APP_NAME}
          </h1>

          <p className={`${current.subtitle} text-slate-500`}>
            {APP_TAGLINE}
          </p>
        </div>
      )}
    </div>
  );
}