export const theme = {
  colors: {
    primary: "#2563EB",
    secondary: "#10B981",
    accent: "#F59E0B",
    info: "#0EA5E9",
    success: "#22C55E",
    warning: "#F59E0B",
    danger: "#EF4444",

    background: "#F8FAFC",
    surface: "#FFFFFF",

    text: "#1E293B",
    border: "#E2E8F0",
  },

  radius: {
    button: "rounded-xl",
    input: "rounded-xl",
    card: "rounded-2xl",
    dialog: "rounded-2xl",
    badge: "rounded-full",
  },

  spacing: {
    section: "py-20",
    container: "max-w-7xl mx-auto px-6",
    card: "p-6",
  },
} as const;